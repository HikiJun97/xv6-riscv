#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"

//myproc() defined at proc.c:83
uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return wait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

void
print_process(struct proc *p)
{
	if (p->state != UNUSED) {
		printf("%d\t", p->pid);
		switch (p->state) {
			case SLEEPING:
				printf("S\t");
				break;
			case RUNNABLE:
				printf("R\t");
				break;
			case RUNNING:
				printf("X\t");
				break;
			case ZOMBIE:
				printf("Z\t");
				break;
			default: break;
		}
		printf("%d:%d.%d\t", (ticks - p->born)/600, ((ticks - p->born)%600)/10, (ticks - p->born)%10);
		printf("%s\n", p->name);
	}
}

uint64
sys_ps(void)
{
	const int MAX_ARG = 6;
	int zero_count = 0; //variable for count number of zero in args[]
	int args[MAX_ARG]; //integer array for storing fetched argument from ps()
	for (int i = 0; i < MAX_ARG; ++i) {
		argint(i, &args[i]); //store fetched argument in args[]
		if (args[i] == 0) {
			zero_count++;
		}
	}

	struct proc *p;
	printf("PID\tState\tRuntime\tName\n");
	if (zero_count == MAX_ARG) {//If all argument is 0, the input command is just "ps".
		for (p = proc; p < &proc[NPROC]; p++) {
			print_process(p);
		}
	}
	else {//If there's arguments not 0
		for (p = proc; p < &proc[NPROC]; p++) {
			acquire(&p->lock);
			for (int i = 0; i < MAX_ARG; ++i) {
				if (args[i] > 0 && p->pid == args[i]) {
					print_process(p);
					break;
				} else if (args[i] < 0 && p->state == (-1) * args[i]) {
					print_process(p);
					break;
				}
			}
			release(&p->lock);
		}
	}
//		if (p->state != UNUSED) {
//			printf("%d\t", p->pid);
//			switch (p->state) {
//				case SLEEPING:
//						   printf("S\t");
//						   break;
//				case RUNNABLE:
//						   printf("R\t");
//						   break;
//				case RUNNING:
//						   printf("X\t");
//						   break;
//				case ZOMBIE:
//						   printf("Z\t");
//						   break;
//				default: break;
//			}
//			printf("%d:%d.%d\t", (ticks - p->born)/600, ((ticks - p->born)%600)/10, (ticks - p->born)%10);
//			printf("%s\n", p->name);
//		}
  // EEE3535-01 Operating Systems
  // Assignment 1: Process and System Call
  return 0;
}
